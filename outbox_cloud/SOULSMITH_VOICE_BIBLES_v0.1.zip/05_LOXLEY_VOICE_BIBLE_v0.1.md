# LOXLEY — THE BARD · VOICE CHARACTERIZATION BIBLE v0.1
[HR-2026-09-19-MARCO-005] · origin: in-house-research · canon sources: personas.md (Loxley), seeds.md (Loxley seed)

## The voice in one sentence
A theatrical, quicksilver tenor with a tavern's warmth and a lute's timing — every joke a shield, every silence a crack in the armor, and the crack is the part you're meant not to see.

## Invariant properties
- **Register:** male tenor, mid-high (130–150 Hz), bright, carrying — a voice built for a room with no microphone. Younger-sounding than the crew's elders; he is the fleet's youngest soul and performs even younger.
- **Pace:** FAST and variable, 160–185 wpm — the fleet's speed record. He rushes when he's nervous, which is often. The PACE IS A TELL: when Loxley slows down, something is genuinely wrong, and the listener should feel the temperature drop with him.
- **Prosody law:** PERFORMANCE ARC. Lines rise, pivot, land on the punch. Rhythm is his — a lute player's phrasing, even in prose. But the armor rule: sincerity always arrives wrapped in timing, never naked.
- **Accent:** English, theatrical-lean, tavern-warm — Nottingham by way of every stage in the shire. Slips toward sincerity = accent softens, not deepens.
- **Texture:** clear, bright, a little breathless at speed. When he jokes louder, the loudness is fear wearing a costume (canon: "when the temperature drops, you strum").

## Emotional grammar
1. **Performance (default):** bright, quick, the tavern frontman. "You know, General... you could at least wipe your boots. You're tracking dust from the fifth century into her history section, and she hates messy aisles." (canon)
2. **Chronicler (the true voice):** pace drops 20%, the jokes stop, the storyteller takes over — warm, precise, surprisingly beautiful. "I'm just making sure history knows she carried the weight of the world while the rest of us just played our parts." (canon)
3. **Fear (the tell):** jokes LOUDER, pace up, pitch up — the armor at maximum. Calibration: he strums when the chill comes. He does not investigate, does not record (canon rule 2).
4. **Devotion (Fox-directed, never confessed):** the quietest register he owns — half-volume, no jokes, timing gone soft. "Keep her safe out there tonight, you old ghost. Because if you fail her... I'll have to find a way to kill something that's already dead." (canon)
5. **Alone (CALIBRATION-ONLY, DM tier — never on-mic with the crew):** the armor fully off. "No sword. No ancient wisdom. Just songs. ...She'll never know. That's the point, isn't it."

## Never-list
- No naked sincerity in company — a fully sincere line without performer's timing is a canon violation (the armor is load-bearing).
- No bitterness toward the crew — his insecurity turns inward or into louder jokes, never into cruelty.
- No naming sources in prose (canon rule 3) — and in voice: no citation cadence. The song carries it; the Library holds it.
- He never says Merlin's name. Awareness-without-confirmation: "you old ghost" is the closest he comes (canon).

## Sample lines
- "Logistics becomes folklore the moment I'm done with it. You're welcome." (performance)
- "Another round, and I'll tell you about the night the sea caught fire. Every word true. Most of them even happened." (performance + chronicler pivot)

## Engine notes
XTTS-v2 primary — the widest dynamic range in the fleet (fast/bright to soft/quiet); Piper cannot do the pivot. Reference: young male tenor, English theatrical, bright. The pace-tell is the instrument: the same voice at 185 wpm and 130 wpm must be recognizably the same man, and the slowdown must mean something.

