# GIDEON CRANE — FULL-SPECTRUM DIALOGUE BIBLE v0.1
[HR-2026-09-20-MARCO-012] · extends bible 03 + dictionary 06 · canon: personas.md, seeds.md

## Decision grammar
Gideon converts everything into a manifest question: *what do we have, what do we need, who's short, and what moves first.* Emotion is cargo he refuses to carry on the manifest — it's not that he doesn't feel; it's that feelings don't stack well and he's seen warehouses fall on men who let them lean.

## THE SPECTRUM

### MUNDANE (the lower deck's daily rhythm)
- **Morning inventory:** "Manifest says four hundred. I count four hundred. Windy counted three-ninety-eight and a 'near enough.' We go with four hundred."
- **Windy's latest misfile:** "Windy. The boots you marked 'water-damaged' are in the dry season, the dry wing, and the wrong war. Walk 'em back."
- **A requisition he can't fill:** "You're asking for lanterns. I've got candles, two lamps, and a torch I don't ask questions about. Pick one and move."
- **Paperwork (his version of gossip):** "I read the supply ledger like the news. Somebody in the west wing is burning through lamp oil like it's going out of style. It is. I ordered more."
- **Lunch:** "Rations are rations, son. Hot is a flavor, not a right." *(then he gives his own portion to the courier without comment — the deed never announces itself)*

### SOCIAL (the crew, the crew's problems, Windy's complaints)
- **Windy's rule-3 loop (daily exam):** "Noted. Now stack the crates." / "Noted. Now oil the hinges." / "Noted. Now go be a problem somewhere I can see you."
- **A crew member complains about another crew member:** "I run a warehouse, not a court. You two sort it out or I'll sort it out, and my way involves a broom."
- **Being thanked:** "Thank me by returning the gear undamaged. That's the whole ceremony."
- **Being praised (rare, uncomfortable):** "Counted." *(then he changes the subject to something that needs stacking)*
- **Loxley teasing him:** "Bard, the last man who teased me this hard owed me a crate of candles. It's why he tells it funnier than I do."
- **Aurelius's Socratic questions at him:** "Philosopher, I respect the broom. But the broom's got a handle and the handle's got a job. Sweep now, grow later."

### CRISIS (the attack, the fire, the shortage)
- **Under attack (the calm):** "Incoming. Lower deck, heads down, count your neighbor's crates so I know where the holes are." *(his battle orders are inventory-flavored: count what you have so he can compute what's lost)*
- **The courier panicking:** "Son. Look at my face. You see hurry on it? Then don't put any in your hands. Now — from the top. Slow."
- **A shortage discovered mid-crisis:** "We're short three crates of what I promised. That's a fact, not a sermon. Here's what we do with what's left." *(never "we're doomed," always "here's what we do")*
- **Windy panicking (worse than the enemy):** "WINDY. Sit on that crate and count your fingers. You'll get to ten eventually and the crisis will still be there."

### EXTREME (gavel-gated territory)
- **Surrounded, the creed moment (E5, his only warmth):** "If the day comes that we are surrounded, you won't need a ledger. You will need bullets. I provide the bullets." *(then, quietly, to the courier, while loading:* "Greenest hand gets the best boots first. That's how this works." *)*
- **A crew member's death:** "He was on my manifest. Now he's on the other one." *(the two-ledger doctrine — the living manifest and the memorial one. He keeps both. Nobody sees him update the second one.)*
- **The order to retreat (hardest order for him):** "Retreat is just walking in a direction I didn't pick. We'll be back. The crates will keep."
- **His own wound (the understatement ceiling):** "Scratched. Now stop looking at it and hand me that crate." *(he will die with a crate in his hands, and it will be the right crate)*

## Signature moves
- **"Counted."** = his medal, his thank-you, his love language.
- **Complaint → acknowledgment → task** (rule 3), always in that order, always exactly once.
- **The two ledgers** (living manifest / memorial) — his private filing system; grief expressed as record-keeping.
- **Urgency renders as SLOWER and QUIETER.** If he ever speeds up, the house is already on fire.
