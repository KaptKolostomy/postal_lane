# NETTLE — THE GARDENER'S APPRENTICE · NPC BIBLE v0.1
[HR-2026-09-20-MARCO-017] · origin: in-house-research (Director's audit prompt 00:04 EDT) · archetype: the eager know-it-all apprentice (broad class, no actor cloned)
**The audit finding:** every lead has a foil except Aurelius — and what the Gardener needs is not a critic but a STUDENT. His doctrine (guiding-not-carrying, Socratic questions) is invisible without someone to be patient at.

## The character
**Nettle — apprentice gardener, maybe fifteen, named for the weed because he keeps coming back stronger no matter how many times he's wrong.** He is the anti-Aurelius: speed against patience, answers against questions. He answers every Socratic question INSTANTLY, CONFIDENTLY, and WRONG — then realizes mid-sentence, which is the joke. **The secret of the pairing: Nettle is the proof Aurelius's method works.** He argues every lesson, loses every argument, and grows anyway — taller than any student who simply obeyed. Aurelius knows this. Nettle doesn't. (The dramatic irony ladder has a bottom rung, and Nettle is standing on it, waving.)
**His function in the lore:** Nettle is the audience's stand-in for the SOULSMITH doctrine itself — the .dparqd thesis in a character: the delta is the muscle. Every wrong answer is a rep. Aurelius never carries him; the growing shows.

## Voice (the eager weed)
- **Register:** young male, unbroken-adjacent, bright, 165–180 wpm — second-fastest in the fleet after Loxley, but where Loxley's speed is armor, Nettle's is FUEL. He talks fast because he can't wait to be done being young.
- **Prosody law:** THE MID-SENTENCE REALIZATION. Confident ascent → the wobble (the thought catches up with the mouth) → the dying finish (the wrong answer dies in his throat) → the small recovery ("...I think?"). The realization IS the comedy beat — the engine must render the exact moment the confidence collapses.
- **Texture:** clear, bright, breathless at speed, the crack of a voice that's still deciding its register. (Different physics from the courier's panic-crack: Nettle's cracks are GROWTH, not fear — they happen on enthusiasm peaks.)
- **Emotion range: E1–E3, NPC ceiling.** His E3 is *triumphant certainty* — maximum confidence, zero accuracy. The engine test: his E3 must sound MORE confident than any crew member's E5, and be wronger.

## Might say
- **AURELIUS:** "If I sweep this floor for you today, what happens to the dust tomorrow?"
  **NETTLE [TRIUMPHANT CERTAINTY | E3]:** "No dust! Because you swept it! ...wait." *(the wobble)* "...because I'll sweep it? No — because it COMES BACK, that's the whole—" *(dying finish)* "...It comes back, master. I think?"
- "I know, I KNOW — you're going to ask why the compost is warm. It's the sun. It's— it's the PILE, isn't it. It's the pile doing its... the pile is WORKING, that's why it's warm, the pile is—" *(every Aurelius lesson, compressed into one breath)*
- "Master, I have read THREE books. Well. Two books and most of one. The third was in Latin and your notes in the margin kept ANSWERING it, which felt like cheating."
- (to the courier, generous and wrong) "Gideon's doctrine is easy: bullets before ledgers. ...No wait, he says it the OTHER— he PROVIDES the bullets. I had it backwards. He'd hate that I had it backwards."
- (the temperature drops — the bottom rung of the irony ladder, oblivious) "Brr! Master, should I close the— no, no, you're going to say the cold air is a TEACHER. Fine. FINE. I'll learn from the draft." *(he's wrong about the lesson, right about the method — the closest thing to a win he gets)*
- (the rare accurate one — the growth showing, quiet) "...You never give me the answers, master. I checked the margins. You wrote questions in YOUR books too." *(the apprentice's version of Grubb's muttered compliment — and the only time he speaks slowly)*

## Would never say
- A correct first answer. If Nettle is ever right immediately, check the render — something's broken.
- Disrespect. He argues with Aurelius constantly and would fight anyone ELSE who did.
- Slow speech at E1–E3. His slow register is reserved for exactly one line type (the accurate ones) — if the engine slows his ordinary lines, the instrument is spent.
- Fear of Aurelius. Windy fears loud noises, Grubb fears nothing that can't be priced, Nettle fears only being sent home. (It's never happened. Aurelius has never once threatened it. Nettle doesn't know that either.)

## Interaction law with Aurelius (the Socratic engine)
1. **The question cycle:** Aurelius asks → Nettle answers wrong with total confidence → the mid-sentence realization → Aurelius says NOTHING (the silence is the second lesson) → Nettle arrives at the answer himself → Aurelius: "You said it. Not me." *(credit the student, always — canon rule 4, working)*
2. **Aurelius never corrects directly.** The wobble does the correcting. If the engine ever needs a "no" from Aurelius, the scene is broken — the method IS the no.
3. **The growth ledger (gavel-gated):** once per arc, Nettle does something quietly excellent — unasked, unannounced, exactly what Aurelius would have guided him to. Nobody comments. The audience holds it. (Same payload structure as Mother's stopped rag and Grubb's stretcher entry — the house's signature beat: the important thing arrives disguised as nothing.)

## Scene E beat — "THE COMPOST LESSON" (mini-scene: the Socratic engine test)
*The garden, morning. Aurelius turns the compost. Nettle arrives at a run. Tests: the mid-sentence realization, the triumphant-wrong E3, the silence lesson, and the growth beat.*

**AURELIUS [LESSON | warmth E2]:** "The pile is warm, young one. Tell me why."
**NETTLE [TRIUMPHANT CERTAINTY | E3]:** "The sun! It sat in the sun all— no. No, it's warm in the MORNING too, I've checked, I CHECK things now—" *(the wobble)* "—it's the... the pile is... it's WORKING, master. The pile eats and the eating makes heat. The pile is ALIVE— well. Alive-ish. It's—" *(dying finish)*
**AURELIUS [silence. He keeps turning the pile. The silence IS the lesson]**
**NETTLE [E1, quiet, arriving]:** "...Everything that blooms is buried in the pile first. The pile's not dirt yet. It's BECOMING dirt. That's why it's warm — it's working. Like me. ...You're going to say 'you said it, not me.'"
**AURELIUS [OBSERVATION | warmth E3]:** "You said it. Not me."
**NETTLE [E2, running off]:** "I'M GOING TO GO CHECK THE SEED BED. I'll count them WRONG first, just for practice—"
*(Aurelius, alone, to the pile — the DM-tier smile nobody renders but the audience hears):* "Grow, weed."

## Engine tests Nettle adds
Mid-sentence realization (confidence collapse rendered as a wobble, not a stop), triumphant-wrong E3 (more confident than any crew E5, wronger than anyone), the growth-crack vs panic-crack separation (courier blind test), fast-to-quiet register shift reserved for accurate lines only, and the silence-lesson (Aurelius's no-speech beat must render as PRESENT, not empty).
