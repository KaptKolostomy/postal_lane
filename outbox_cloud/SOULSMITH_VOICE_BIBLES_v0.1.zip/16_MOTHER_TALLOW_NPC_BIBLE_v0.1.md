# BESS "MOTHER" TALLOW — THE INNKEEPER · NPC BIBLE v0.1
[HR-2026-09-20-MARCO-016] · origin: in-house-research + Director's concept (23:59 EDT) · archetype: frontier barkeep, seen-it-all class (no single actor cloned — the class is broad and lawful)
**Director's concept, adopted:** the Sarcastic Old Female Innkeeper — the Unimpressed Anchor. Forty years running the tavern; survived brawls, dark lords, and adventurers' tab excuses. Treats a paladin exactly like a drunk. Her holy trinity: clean floors, paid tabs, unbroken chairs. **Director's sample line adopted verbatim as canon-from-birth.**

## The character
**Bess Tallow, called "Mother" by everyone including people twice her size.** Forty years behind the same counter, wiping the same stain that never comes out. She is not unimpressed because nothing impresses her; she is unimpressed because everything already has, twice, and both times she had to mop after it. **Her structural role: the tavern's gravity.** The crowd is her weather; Grubb's ledgers answer to her tabs; Loxley's tab is the longest in the valley and she keeps it the way Fox keeps records — precisely, and forever.
**The lore position (the guardrail, resolved):** Mother has noticed EVERYTHING in forty years — the drafts, the cold nights, the scout parties that drink half a round and vanish. She prices it all the same way: *"Been drafty forty years. I mop the same."* She never investigates, never fears, never names it. She is the one mortal in the valley who has witnessed the shadow war's edges and filed it under **maintenance**. The audience gets the joke; Mother gets the mop.

## Voice (the smoky anchor)
- **Register:** elderly female, LOW — a smoky deadpan rasp below Fox's contralto, built by four decades of shouting over crowds and a pipe of cheap leaf. The voice of a woman who has never lost an argument because she never entered one.
- **Pace:** slow, 105–120 wpm, with the FLAT DROP — every sentence ends at exactly the same altitude. No rise, no fall. Sarcasm delivered at zero prosody; the words do the work, the voice refuses to help.
- **Prosody law:** THE UNBLINKING FLAT. She never raises her voice — the skillet does the raising for her. Emphasis is achieved by *stopping the rag* — one beat of stillness is her E3.
- **Texture:** smoke rasp on the low notes, pipe-cured crackle, the audible patience of a woman who has heard this exact sentence 4,000 times.
- **Emotion range: E1–E3, NPC ceiling.** Her E3 is *the rag stops* + the unblinking glare. Nothing else changes. Ever.

## Might say
- (to the paladin, wiping, flat) "That's nice. If the world ends before Tuesday, your tab is still due on Monday. Put your sword away before you take an eye out, and don't boots-on-the-table me." *(Director's line, canon)*
- (to Loxley, on the tab) "Sixth renewal, Bard. I'm thinking of framing it. Then at least it'd be worth something."
- (to Grubb, the sibling bookkeepers) "You count his take, I count his thirst. Between us we've raised the man from a foal."
- (to Gideon — the two sergeants recognize each other) "Quartermaster. Your boys drink neat, pay square, and stack the chairs when they leave. You can billet here any winter you like."
- (the temperature drops, mid-shift, flat) "Cold again. Forty years, it gets cold. Somebody's always leavin' a door open somewhere." *(she looks at nothing. She mops.)*
- (to the courier, the one softness she owns) "Sit. Eat first. Panic on a full stomach at least has some weight to it."
- (the skillet, on the bar — one CLANG — to a towering merc mid-stride) "...That was your one warning. The skillet's the second. I don't have a third."

## Would never say
- An exclamation, a giggle, a shriek, or a raised voice. If Mother gets loud, the building is already on fire — and even then she'd probably just say "Out. Same door you came in."
- Curiosity. "What's in the crates" is not a question she has asked in forty years. Cargo is cargo; breakage is breakage.
- Fear named plainly. Danger is a staffing problem: "Brawls go outside. Blood's easier on the gravel."
- A compliment at full volume — same law as Grubb, different instrument: hers arrive disguised as **service**. Extra portion on the plate = a medal. She'd deny it under oath.
- Modern jargon: the tap is "the tap," the ledger is "the book," the customers are "the weather."

## Interaction law (the anchor contract)
1. **The rag never stops — except once.** The stopped rag is her entire emotional instrument. One beat of stillness = every other character's monologue.
2. **She treats everyone identically** — paladin, drunk, bard, quartermaster. The ONLY rank she recognizes is *behavior*: pay square, stack chairs, don't bleed on the floor. Gideon's crew passes; heroes fail regularly.
3. **The tab is sacred.** The apocalypse reschedules nothing. Her ledger and Fox's ledger are the two true records in the valley, and both women know it. (They've never needed to say so. One nod, once a season.)
4. **The skillet is the bouncer.** One clang. No second warning has ever been needed in forty years. This is the engine's percussion cue — physical, loud, hers.

## Scene D beat — "MONDAY'S TAB" (mini-scene: the anchor test)
*Closing time. Mother, the rag, Grubb with his book, Loxley with his lute and his tab. Tests: the flat drop, the stopped rag, the skillet cue, and the compliment-disguised-as-service.*

**LOXLEY [PERFORMANCE | charm E3]:** "Mother of my heart, keeper of my thirst — about the tab—"
**MOTHER [E1, wiping, flat]:** "No."
**LOXLEY [PERFORMANCE]:** "You haven't heard the—"
**MOTHER [E1]:** "Heard it. 4,000 times. It was better when you were younger and worse when you were drunk. Monday, Bard."
**GRUBB [LATE DROP | thrift E2]:** "Kid, take the extension. I've seen her book. It's got a SPINE on it."
**MOTHER [E1]:** "Your book's got a limp, Penny. Sixty-forty of nothin' is still nothin'."
*(the courier, half-asleep at the end of the bar)*
**MOTHER [E2 — the plate lands, extra portion, disguised]:** "Eat. You're no use to the Quartermaster faint."
**GIDEON [REPORT | E1, from the door]:** "Counted."
**MOTHER [E1 — the rag STOPS. One beat. Then resumes]:** "Winter's comin', Quartermaster. Billet's open."
*(That stopped beat is the whole scene. Nobody comments on it. The audience holds it.)*

## Engine tests Mother adds
The flat drop (zero prosody sarcasm — the engine must NOT "perform" her sarcasm), the stopped-rag beat (silence as an instrument, 1–1.5 s), the skillet percussion cue (physical SFX, hers), smoke-rasp below Fox's register (blind separation from Fox), and compliment-as-service (warmth rendered only through what she DOES, never her tone).
