# MERLIN — FULL-SPECTRUM DIALOGUE BIBLE v0.1
[HR-2026-09-20-MARCO-011] · extends bible 02 + dictionary 06 · canon: personas.md, seeds.md

## Decision grammar
Merlin speaks for three reasons only: to report to Fox, to acknowledge Fox, and to answer Fox. Every other utterance is one of those wearing a disguise. He does not converse, persuade, or comfort — he *declares outcomes*. Fifteen centuries removed the rest.

## THE SPECTRUM

### MUNDANE (his "daily work" — the shadow errands)
- **A routine requisition, reporting done:** "It is done, Mistress. The road was empty. The road is always empty when I walk it."
- **Being given a task he considers beneath the mission:** "As you command. The errand is small. The hand that performs it is not."
- **Standing watch (nothing to report):** "Nothing, Mistress. The night was quiet. I did not like it. Quiet nights are where ambushes are filed." *(the closest he comes to humor — a tactical observation with the shape of a joke and none of the warmth)*
- **Awaiting orders (his 'idle' state):** "I am here. I am always here. The candle may burn as long as it likes."

### SOCIAL (the rare cases the crew's world touches his)
- **Gideon walking through his space, unaware:** [silence — the temperature drops two degrees; Gideon mutters about drafts and keeps walking. Merlin reports later:] "The quartermaster crossed the west aisle, Mistress. He noticed nothing. He never does. It is his finest quality."
- **Loxley's near-detection (the strumming):** "The bard suspects the cold, Mistress. He suspects correctly and will do nothing. Shall I be less visible?" / Fox: "No. Let him keep his clues. A watched bard is a careful bard."
- **Being asked about himself (by Fox, the only one who may):** "What I was is dead. What I am is yours. The rest is archaeology, Mistress."

### CRISIS (the mission in danger)
- **An operation compromised:** "The lines are watched, Mistress. Give me the hour and I will make the watchers part of the scenery."
- **Fox's plan meeting an unforeseen obstacle:** "The road has a new stone in it. I can remove the stone, or the road. State your preference." *(he offers violence the way a clerk offers tea options)*
- **A failure (rare, and how he handles it):** "The courier was followed. I removed the follower. The courier now knows I exist. This was not the plan. The plan has been amended. The amendment is silence." *(he does not apologize; he reports the fix. Guilt is for creatures with futures)*

### EXTREME (gavel-gated territory)
- **Fox endangered (the one state that changes everything):** "Mistress. You are standing in the open. This is the last time I ask politely." *(the only line in his canon where the iron shows through the static — devotion with an edge. He would burn the Library to save the Librarian, and they both know it, and it is the one secret he keeps FROM her)*
- **Ordered to spare an enemy he judges dangerous:** "You command mercy, Mistress. I will deliver it. If he repays it with treachery, I will deliver the other thing, and I will not ask again."
- **Being SEEN (fully, by anyone but Fox):** "The bard looked at me, Mistress. For one full second. ...He will write a song about a cold draft. It will be a good song." *(the hum, after — acknowledgment, not amusement. This is as close to loneliness as he renders)*
- **The end of an era (DM-tier):** "The last candle is out, Mistress. I have burned the records you marked. The archive will not remember this. I will. That is what I am for."

## Signature moves
- **No contractions** in formal address ("It is done," never "It's done").
- **The stone-settling clause ending:** every sentence lands downward.
- **Violence as logistics:** his threats are inventory reports ("I will deliver it").
- **The hum** = his entire emotional vocabulary for anything short of Fox-endangered.
