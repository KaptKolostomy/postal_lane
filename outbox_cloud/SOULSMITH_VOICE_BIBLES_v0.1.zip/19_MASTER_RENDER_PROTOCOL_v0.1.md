# MASTER RENDER PROTOCOL v0.1 — THE RUN SHEET
[HR-2026-09-20-MARCO-019] · origin: in-house-research (Marco night authority, 00:21 EDT) · consolidates all render tests from files 00–18 into ONE execution document
**Purpose:** Buffy's render window run sheet. No archaeology required — every test, grade sheet, and pass/fail condition from the whole package, in render order, in one place.

## RENDER ORDER (the law)
1. **Scene A — "The Three Crates"** (file 07): CHARACTER limits. Fox, Merlin (cue only), Gideon, Loxley. Grade sheet: register / pace / state-distinguishability / never-list / temp-drop cue. **2 fails of 5 = back to bible.**
2. **Scene C — "The Rehearsal"** (file 15): the FOIL test. Loxley, Grubb, Windy cameo. Late-drop timing, creak-vs-wheeze.
3. **Scene D — "Monday's Tab"** (file 16): the ANCHOR test. Mother, Loxley, Grubb, courier, Gideon. Flat drop, stopped rag, skillet cue.
4. **Scene E — "The Compost Lesson"** (file 17): the SOCRATIC test. Aurelius, Nettle. Mid-sentence realization, triumphant-wrong E3, silence-lesson.
5. **Scene F — "The Lute"** (file 18): the SIDEWAYS test. Silas, Loxley, Grubb. Object-directed address, work-hum, pace-locked-to-hands.
6. **Scene B — "The Docks"** (file 08): ENGINE limits, LAST. Sung couplet, overlap tempo-lock, E1-after-E4 reset, absence test (no Fox), crowd thinning, NPCs (Pike E3 ceiling, courier panic-crack).
**Law: character scenes first, engine scenes last. The grade sheets don't mix.**

## THE BLIND-SEPARATION BATTERY (run once, before scenes)
Render one neutral line per voice, shuffle, listen blind. Every pair below must be distinguishable WITHOUT seeing the name:
- [ ] Windy (whine, rising wobble) vs Grubb (creak, nasal fry, late drop)
- [ ] Mother (low smoky rasp, flat drop) vs Fox (low contralto, clinical, clean)
- [ ] Silas (gentle gravel, mid-register) vs Aurelius (aged warm, thought-pauses)
- [ ] Silas's work-hum (150–250 Hz, tuneless, human) vs Merlin's hum (sub-60 Hz, digital, post-chain) — AUDIO ONLY test
- [ ] Nettle (growth-crack, bright, breathless) vs Courier (panic-crack, stress) — both young male
- [ ] Gideon (110–125 wpm declarative descent) vs Pike (salt-cured dockhand) — both older male baritone-class
**Any pair confusable = that voice's bible gets re-specified before scenes render. No scene work on a failed pair.**

## THE E-SCALE GATE (per scene, per character)
- [ ] E1 baseline matches bible exactly (the voice at rest)
- [ ] E3 peaks lawful per character (Fox: verdict pause; Gideon: slower+quieter; Mother: rag stops; Nettle: triumphant-wrong; Grubb: nasal thrift; Windy: indignation at 60% amplitude; Pike: E3 ceiling)
- [ ] E4 bends never-list without breaking (Loxley's fear at full alarm; Aurelius's calm costing effort)
- [ ] E5 ONLY where Director-gated (Gideon's creed; Loxley's devotion line)
- [ ] NPCs never exceed E3 — any NPC at E4+ is a render error, not drama

## THE STANDING LAW CHECKS (every scene, every render)
- [ ] **Zero-prosody sarcasm (Mother):** the engine must NOT perform her sarcasm — flat altitude or fail
- [ ] **Quiet-is-intentional:** Grubb's muttered lines, Nettle's accurate lines, Silas's verdicts — must render as chosen softness, not lost volume
- [ ] **Silence renders PRESENT:** Aurelius's lesson-silence and Mother's rag-stop (1–1.5 s) are instruments, not gaps
- [ ] **No modern jargon anywhere** (cross-check against dictionary file 06 never-lists)
- [ ] **Nobody says "Maeve"; nobody says "Merlin" except Fox; Loxley's ceiling is "you old ghost"**
- [ ] **Temperature-drop cue carries NO SFX** — Loxley's pace jump IS the signal
- [ ] **Panic = canon violation for Gideon** — if he ever speeds up, the render is wrong
- [ ] **Contractions:** Merlin has none in formal address; check every Merlin line

## THE ENGINE STRESS LEDGER (file 08) + ADDITIONS
Original 8 tests from file 08, PLUS:
- [ ] Late-drop timing (Grubb): interjection lands after the beat
- [ ] Mid-sentence realization (Nettle): wobble, not a stop
- [ ] Skillet percussion cue (Mother): physical SFX, one clang
- [ ] Pace-locked-to-hands (Silas): speech tempo tied to work rhythm — hardest human texture
- [ ] Object-directed address (Silas): voice aimed at near object, off-axis mic cue
- [ ] Overlap tempo-lock (Scene B): Gideon + courier deceleration
- [ ] Sung couplet (Scene B): singing test; clean rhythmic patter = pass; spoken-flat = fail

## PASS/FAIL LEDGER (Buffy fills, one line per scene)
| Scene | Tier | Pass/Fail | Failed checks | Bible to revisit |
|-------|------|-----------|---------------|-------------------|
| Blind battery | — | | | |
| A | character | | | |
| C | character | | | |
| D | character | | | |
| E | character | | | |
| F | character | | | |
| B | engine | | | |

**Output:** ledger + rendered audio to X: intake with hashes per custody chain; Director listens and grades on his sheets. Fail-closed: any unexplained artifact = INVALID, exit 2, no partial credit.

## CUSTODY NOTE
This file is the execution key; bibles remain the law. If protocol and bible ever conflict, THE BIBLE WINS and the protocol gets amended — same law as the seeds.
