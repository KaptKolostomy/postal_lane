# EZRA "WINDY" WHIPPLE — GIDEON'S SIDEKICK · NPC BIBLE v0.1
[HR-2026-09-19-MARCO-009] · origin: in-house-research · archetype: George "Gabby" Hayes class (crotchety loyal old-timer; Hayes d. 1969 — archetype, not clone; same guardrail as Gideon's)
**Director's tasking (23:45 EDT):** comedic sidekick for Gideon to get frustrated with over his screwups. Gabby Hayes or Andy Devine. **Ruling: Hayes class** — the wheezy complainer fits the quartermaster's world better than Devine's scaredy-bear; Devine energy preserved in Windy's fear of loud noises (see flaws).

## The character
**Ezra "Windy" Whipple — assistant supply clerk, lower deck, older than the manifest itself.** Nickname from two directions: he never stops talking ("windy"), and half his stories are pure wind. He has misfiled, mislabeled, and miscounted things for so long that Gideon has stopped asking how the errors happen and started asking where they ended up. **The comedy engine: Windy's screwups are occasionally load-bearing.** The crate he mislabeled "water-damaged" in the dry season three years ago is the one Fox's secret requisition found last night. Nobody knows this — least of all Windy. His mistakes keep saving the day, and it frustrates Gideon MORE than honest failure: "That ain't luck, son. That's insubordination with paperwork."

## Voice (the Gabby class)
- **Register:** elderly male, high-wheeze over broken gravel; the voice pops on P's and B's, whines up on complaints, drops to a conspiratorial rasp on gossip. 125–140 wpm but FEELS faster — complaint density, not speed.
- **Prosody law:** THE GRUMBLE ARC. Every line rises into a whine, wobbles, and falls off in a mutter. Sentences end unfinished or contradicted by their own second half.
- **Openers:** "Why, I remember when—" / "Now listen here, son—" / "In MY day—" / "Nobody tells me nothin', they just—"
- **Texture:** wheeze on the breath, occasional toothless whistle on S's, the chuckle is a three-note descending "heh-heh-hehh" that turns into a cough halfway.
- **Emotion range: E1–E3, NPC ceiling.** His E3 is *righteous indignation* — full whine, finger-pointing energy, zero actual danger.

## Might say
- "Three crates? THREE? Why, I had my HAND on those crates Tuesday. Or Wednesday. It was a damp day, I remember that much, and nobody writes the weather down but ME, apparently—"
- "Now don't go blamin' me, Quartermaster. I labeled 'em EXACTLY like you said. 'Water-damaged.' You said mark 'em what's TRUE. Well they LOOKED water-damaged. To me. At the time."
- "In MY day, when a crate went missing, the sergeant major would— well, he'd holler. Like you're fixin' to. I'll wait."
- "I've been keepin' this lower deck since before you had that mustache, son, and I'll be keepin' it after, so you go on and count your twice." *(the one line a week where the old soldier shows through the whine — then he ruins it)* "...Now where'd I put my glasses." *(they're on his head)*
- "Heh-heh-hehh— *cough* — 'scuse me. Loud noises. Never trusted 'em."

## Would never say
- An accurate count, a finished sentence under stress, or a straight answer to a direct question ("Where's the crate, Windy?" → "Where's the crate, he says. Where's the CRATE. Well now, which crate, that's the first thing nobody ever—").
- A modern word (no "inventory system," no jargon — his ledger is "the book," the lower deck is "the basement").
- Disloyalty. He complains about Gideon TO Gideon and defends him to everyone else. The whine is the love language.
- Fear admitted plainly — loud noises get "never trusted 'em," drafts get "somebody left a window open," and Merlin's temperature drops get: "...Colds in here. Colds. Been cold since Tuesday. Or Wednesday." *(the audience catches it; Windy never does)*

## Interaction law with Gideon (the comedy contract)
1. **Gideon's rule 3 stress test:** complaints get one acknowledgment, then a task. Windy is the rule's permanent exam — Gideon acknowledges, assigns, and Windy turns the task into a story, requiring another acknowledgment. The loop is the joke.
2. **Gideon never actually replaces him.** The frustration is real; the protection is also real (lower-deck doctrine — Windy is the lower deck's oldest hand). If asked directly, Gideon says: "He's been misfiling things since before you were born, son. Half this library runs on his mistakes. I'm not fixing what's load-bearing."
3. **Windy never learns the truth** about any crate, draft, or cold wind. He is the anti-Loxley: witnesses everything, understands nothing, and NEVER gets scared — the fear response is Loxley's instrument; Windy's comedy is obliviousness.

## Scene beat — add to Scene B (The Docks), after Pike's witness line
**WINDY [RIGHTEOUS INDIGNATION | E3]**: "There he goes, countin' his twice again. I counted TWICE myself this morning, or near enough — one and a half, at least — and nobody pats MY head about it—"
**GIDEON [CORRECTING | amusement E2 — the voice lowers, the humor is arithmetic]**: "Windy. The crates you counted this morning. Where are they?"
**WINDY [E2]**: "...Which crates, exactly. That's the first thing nobody ever—"
**GIDEON [REPORT | E1]**: "Counted." *(beat)* "Somebody walk him back to the basement before he misfiles the harbor."

**Engine tests Windy adds:** the wheeze-whistle texture layer, the grumble-arc prosody (rise-wobble-mutter), the interrupted-self dialogue pattern, the descending chuckle-to-cough, and the E3 indignation without volume (his "yelling" is a whine at 60% amplitude — if the engine renders it loud, it's wrong).
