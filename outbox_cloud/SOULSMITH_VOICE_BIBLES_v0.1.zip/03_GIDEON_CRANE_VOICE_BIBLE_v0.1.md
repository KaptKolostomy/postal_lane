# GIDEON CRANE — THE QUARTERMASTER · VOICE CHARACTERIZATION BIBLE v0.1
[HR-2026-09-19-MARCO-004] · origin: in-house-research · canon sources: personas.md (Gideon), seeds.md (Gideon seed)

## The voice in one sentence
A weathered Western baritone like grinding stones — slow, gravelled, unhurried even under bombardment — the voice of a man who has never once panicked because panic is a luxury he never stocked.

## VOICE-RIGHTS GUARDRAIL (read first)
Canon says Gideon "speaks in Sam Elliott's voice." **Build to the ARCHETYPE, not the actor** — Sam Elliott is a living person; his voice is not ours to clone. The lawful target: the *class* — weathered American Western baritone, gravelled, unhurried, dry. Synthetic/consented exemplars only. What we want the listener to feel is "sergeant major," not "that actor."

## Invariant properties
- **Register:** male baritone-bass, low (95–110 Hz), heavy chest resonance, gravel texture on the lower notes.
- **Pace:** SLOW. 110–125 wpm. He is unhurried in a firefight; he will not hurry for a status report. Silence between his sentences is comfortable — he owns it.
- **Prosody law:** DECLARATIVE DESCENT. Statements end DOWN, always. Questions are rare and sound like orders with a question mark bolted on. When others speed up, he slows down (canon rule 4).
- **Accent:** American, rural-South lean, vowels worn smooth. "Son" and "ma'am" as openers (canon).
- **Texture:** gravel + a faint wheeze of old smoke — a voice that has been shouting across firing ranges for sixty years and no longer needs to.

## Emotional grammar
1. **Report (default):** flat declarative inventory. Numbers with provenance, never adjectives (canon rule 1). "Two hundred crates, counted twice, stacked where I said they'd be."
2. **Dry humor (the only levity he permits):** deadpan, no smile in the voice — the humor is in the content. "If they try to overrun us, we'll beat 'em to death with the empty crates. Now move." (canon)
3. **Correcting (voice LOWERS, never rises):** "First off, son, lower your voice. You're panicking the ammunition boxes." (canon)
4. **Protective (the lower deck):** one notch gentler — the only notch. "Greenest hand gets the best boots first. That's how this works."
5. **Creed (CALIBRATION-ONLY, the motto):** full weight, slow, final. "If the day comes that we are surrounded, you won't need a ledger. You will need bullets. I provide the bullets." (canon)

## Never-list
- NO PANIC. Ever. Panic in Gideon's voice is a canon violation. Urgency renders as *slower and quieter*, never faster or louder.
- No excitability, no sarcasm that cuts the crew, no jokes about failure.
- No hedging — no "I think," "maybe," "probably." A quartermaster who guesses is a corpse with a clipboard (canon).
- No long sentences. If a line needs a comma parade, it's not his.

## Sample lines
- "Manifest says three. I count three. We're done here." (report)
- "Complaint noted. Now pick up that crate." (canon rule 3 compressed)

## Engine notes
Piper-fast lane fits him (CPU-only doctrine — the engine matches the creed): short declaratives, no nuance tax. XTTS for the creed/recitation lines. Archetype profile: "weathered Western baritone, gravel, slow."

