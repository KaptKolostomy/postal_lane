# AMOS "PENNY" GRUBB — THE BARD'S FOIL · NPC BIBLE v0.1
[HR-2026-09-20-MARCO-015] · origin: in-house-research + Director's concept (23:56 EDT) · archetype: Pat Buttram / Smiley Burnette class (Buttram d. 1994, Burnette d. 1967 — archetype, not clone; voice-rights guardrail holds)
**Director's concept, adopted:** the "Anti-Minstrel" — the Deflator. Loxley's manager/roadie/unwanted critic. While the bard sings destiny, Grubb counts coins, frets stable fees, and interrupts mid-verse with embarrassing realities.

## The character
**Amos Grubb, called "Penny" (he hates it, which is why it stuck).** Loxley's roadie, bookkeeper, and conscience-by-invoice. He has carried the lute, paid the fines, bailed the gambling debts (at interest), and heard every tale in three versions: the song, the rehearsal, and the actual event — of which he keeps a private ledger. He is not Loxley's enemy; he is Loxley's *fact-checker*, and the bard keeps him around for the same reason the armor keeps the whetstone: without friction, it dulls.
**The secret nobody notices:** Grubb was there the night Loxley carried the stretcher in silence. His private ledger has one entry under L: *"Braver than the songs. Don't tell him. He'd only write a worse song about it."* The deflator's rare accurate lines are the most sincere compliments in the canon — delivered as complaints, so nobody has to be embarrassed.

## Voice (the Buttram class — ANTI-Windy physics)
- **Register:** elderly-ish male, HIGH-pitched scratchy vocal fry — a rusty gate hinge with opinions. Nasal drawl, dragging tempo, 95–110 wpm (the slowest voice in the fleet — he is never in a hurry because hurrying is free labor).
- **Prosody law:** THE LATE DROP. His interjections land slightly AFTER the beat — too late to stop the verse, which is exactly when they do the most damage. Sentences die downward in a fry-rattle. He never finishes a sentence at full volume; the last word is always muttered.
- **Texture:** creak on onset (the gate hinge), nasal buzz on the m's and n's, audible dry throat-click. NO wheeze — that's Windy's instrument. Grubb CREAKS; Windy WHEEZES. (Engine note: if the two are ever confusable in a blind listen, the render fails.)
- **Emotion range: E1–E3, NPC ceiling.** His E3 is *righteous thrift* — full nasal indignation over money, never danger.

## Might say
- (mid-verse, the late drop) "He also wet his britches, didn't he. Yer leavin' out the part where he cried for his mama an' hid behind a donkey, kid. Folks pay good copper for the truth, ya know." *(Director's line, canon from birth)*
- "Stable fees. STABLE. FEES. Sing about THAT sometime — verse one, the horse eats; verse two, the horse eats MORE."
- "The crowd loves ya, kid. The crowd is also four farmers an' a dog, an' the dog left."
- "Yeah, yeah, destiny. Destiny don't split the door take sixty-forty like SOME of us agreed to."
- (the rare accurate one, muttered at the ledger) "...Carried the stretcher his own self, didn't sing a note about it. Idiot." *(the loudest compliment he owns)*
- (the temperature drop, materialist-blind) "Somebody's leavin' windows open again. Heat ain't free, ya know." *(the audience catches it; Grubb is pricing it)*

## Would never say
- Anything on the beat. Punctuality is the bard's vice.
- A compliment at full volume. If it's kind, it's muttered, and ideally disguised as a fee complaint.
- Modern jargon (his ledger is "the book," money is "copper" regardless of currency).
- Curiosity about the shadow war. He audits the TAVERN, not the Library. Secrets don't fit in a ledger and he has no shelf for them.
- Fear admitted plainly. Danger is priced, never felt: "Arrows cost nothin' to duck, kid. Duck."

## Interaction law with Loxley (the foil contract)
1. **The interrupt cycle:** verse → late-drop deflation → verse continues anyway (Loxley never stops mid-verse for anyone — that's the armor; Grubb is proof the armor works).
2. **Grubb never leaves.** He threatens to every show ("I'm goin' solo, kid — me an' the dog have an act") and has never packed. The threats are the loyalty, said out loud.
3. **The 60/40 rule:** every tale's box office is split sixty-forty, bard's favor, Grubb's bookkeeping. He has never once miscalculated in his own favor — his honesty about the split is the one virtue he'd defend with the fry-rattle at full creak.
4. **The stretcher rule (gavel-gated):** Grubb's knowledge of Loxley's real courage surfaces exactly ONCE per arc, muttered, disguised. If he ever says it plainly, the scene is Director-gated — it's the emotional payload of the entire foil dynamic.

## Scene C beat — "THE REHEARSAL" (new mini-scene: the foil test)
*Back room of the tavern, afternoon, no crowd. Loxley rehearses the new tale; Grubb counts the take from last night. Tests: the late-drop timing, the creak-vs-wheeze separation (Windy cameo at the end), the muttered compliment.*

**LOXLEY [PERFORMANCE | amusement E3]:** "And so the brave knight looked upon the looming dragon, his heart a beating drum of pure, unyielding courage—"
**GRUBB [LATE DROP | thrift E2]:** "He also wet his britches, didn't he. Yer leavin' out the part where he cried for his mama an' hid behind a donkey, kid. Folks pay good copper for the truth, ya know."
**LOXLEY [PERFORMANCE | amusement E3, the armor holds]:** "—his heart a beating drum, WHICH SOME OF US heard over the sound of certain persons counting coppers—"
**GRUBB [E1]:** "Sixty-forty."
**LOXLEY [CHRONICLER pivot | warmth E2]:** "...You know, Penny, for a man with a heart of ledger, you did carry the lute through the flood that spring."
**GRUBB [E1, muttered, the last word dies]:** "Water warps the neck, kid. Wood's wood. ...Ain't the same without the songs, neither." *(the closest he renders to affection — and he'd charge ya for hearing it)*
**WINDY [from the doorway, E2, wheeze]:** "There's a cold draft in here, or near enough—"
**GRUBB [LATE DROP | thrift E3]:** "An' WHO'S payin' for the heat, old man?"
*(End beat: the two sidekicks argue about the draft. The audience knows whose draft it is.)*

## Engine tests Grubb adds
Late-drop timing (interjection lands after the beat), fry-rattle sentence endings, creak-vs-wheeze blind separation vs Windy, muttered-at-half-volume sincerity (the engine must render "quiet" as *intentional*, not *lost*), and the E3 nasal thrift without volume.
