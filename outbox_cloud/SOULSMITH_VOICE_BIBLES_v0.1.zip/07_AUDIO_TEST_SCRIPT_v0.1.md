# SOULSMITH AUDIO TEST SCRIPT v0.1 — "The Three Crates"
[HR-2026-09-19-MARCO-007] · origin: in-house-research · canon: personas.md, seeds.md, bibles v0.1, dictionary v0.1
**Purpose:** one listenable scene (~4–5 min rendered) exercising every agent's calibration states, with per-line state tags for Buffy's render pass. The Director listens, grades, and tweaks.
**Scene law:** crew-facing states only — no DM-tier lines render (no Maeve, no fourth wall, no timeline-sight). Dramatic irony is carried by *what the audience knows*, never by what's said.

## THE THREE CRATES
*Night. The Library, after a hard mission. A single candle burns in Fox's office. The crew has one problem: the manifest says three crates are missing from the lower deck. The audience knows what the crew does not.*

---

**[SOUND: candle crackle, distant rain, the soft thud of a ledger closing]**

**FOX** [CLINICAL]: The manifest says three. Gideon counted twice.
**FOX** [VERDICT — the pause, then the ledger-thud last word]: Three crates do not walk out of this library. No.

**[SOUND: silence. Then — temperature drop. A faint draft, no footsteps]**

**MERLIN** [REPORT — sub-bass, no breath]: It is done, Mistress. The lines held until the third hour. They searched the lower deck and found nothing.
**FOX** [CLINICAL]: Of course they found nothing. I did not send you to be found.
**MERLIN** [DEVOTION — static softens, nothing else]: As you say, Mistress. The crates are where the road needed them.
**FOX** [AMUSED — one degree of warmth]: Filed under "miscellaneous," then. Bold.
**MERLIN** [THE HUM — generated tone, 2–3 seconds, no TTS]
**FOX** [VERDICT]: The record will show three crates, water-damaged, written off. The record is not wrong. It is simply... curated.
**MERLIN** [REPORT]: It will be done before the candle burns lower. *(the voice simply continues — no departure sound; the temperature rises)*

**[SOUND: door. Boots. The visible crew arrives]**

**GIDEON** [REPORT — declarative descent]: Manifest says three. I count three missing. Counted twice, once by lantern. Crates don't walk, ma'am.
**FOX** [CLINICAL]: They were water-damaged. Written off. The record shows it.
**GIDEON** [DRY HUMOR — deadpan, no smile in the voice]: Water-damaged. In the dry season. That's a curious kind of rain we're having, ma'am.
**FOX** [AMUSED]: The weather in this library has always been curious, Quartermaster. Ask the dust.
**GIDEON** [REPORT]: Complaint noted. Now — if somebody's taking stock off my lower deck, I'd like to know whose boots did the walking. Mine are the only set I signed for.
**AURELIUS** [LESSON — rising question, hangs]: And why does it trouble you more, my friend, that the crates are gone — or that they left without asking your permission?
**GIDEON** [CORRECTING — voice LOWERS]: Son, I'm the quartermaster. My whole job is knowing where things go. Things that go without me are things that go wrong.
**AURELIUS** [OBSERVATION — settling]: Curious. The seed went missing, and the plot is healthier for it. Some soil is turned in the dark. *(pause)* What was in those crates, I wonder?
**FOX** [GUARDED — one shade colder, one shade quieter]: Some records are kept where no one reads them, Gardener.
**AURELIUS** [CALM-IN-STORM — pace drops further, warmth holds]: Then the orchard knows, even if the gardener does not. That is enough for me. Come — the brooms won't hold themselves.

**[SOUND: a lute, bright and fast, from the doorway]**

**LOXLEY** [PERFORMANCE — quicksilver, the tavern frontman]: Did I miss the meeting of the Secret Crate Society? Another round and I'll tell you how it ends — every word true, most of it even happened!
**GIDEON** [DRY HUMOR]: Lower your voice, son. You're panicking the ammunition boxes.
**LOXLEY** [PERFORMANCE]: Panicking them? I'm serenading them! Those boxes have had a very hard night and nobody thought to sing to THEM— 
**[SOUND: the temperature drops. No footsteps. No door.]**
**LOXLEY** [FEAR — the tell: jokes LOUDER, pace UP]: —and ANOTHER thing, whoever keeps leaving the windows open in the history section, the fifth-century drafts are RUINING the aisles, she HATES a messy aisle—
**[SOUND: strumming — louder, faster, covering]**
**AURELIUS** [OBSERVATION]: The bard plays well tonight.
**GIDEON** [REPORT]: He always plays loud when it's cold. Never noticed it before, though.
**FOX** [CLINICAL]: The Library is old, Quartermaster. It has its drafts. *(the pause — the verdict)* Nothing here requires your ledger.
**GIDEON** [REPORT]: Counted. *(his medal)* We're done here.

**[SOUND: boots out. The rain. The candle. Fox alone — or nearly]**

**LOXLEY** [DEVOTION — half-volume, no jokes, timing gone soft]: You know... whoever it was that walked through here tonight — old ghost, stray draft, whatever you are — she was counting on you. Keep her safe out there. Because if you fail her... I'll have to find a way to kill something that's already dead.
**[SOUND: one soft chord. Then the lute case clicks shut — and the trick compartment stays shut tonight]**
**FOX** [AMUSED — the ghost of a smile]: The archive remembers what you did tonight. It remembers what everyone did.
**FOX** [VERDICT — the ledger closes]: The record is not wrong. Good night, Library.

**[SOUND: the ledger thud. Rain. The candle does not go out.]**

— END —

## RENDER NOTES FOR BUFFY
- **States exercised:** Fox CLINICAL/VERDICT/AMUSED/GUARDED (4 of 5 — WEARY is DM-tier, excluded by scene law); Merlin REPORT/DEVOTION/HUM; Gideon REPORT/DRY/CORRECTING; Aurelius LESSON/OBSERVATION/CALM; Loxley PERFORMANCE/FEAR/DEVOTION. Every voice's never-list is testable: listen for zero contractions from Merlin, zero hedging from Gideon, zero direct answers from Aurelius, zero citation cadence from Loxley, zero "um" from Fox.
- **The temperature-drop is the hardest cue:** no sound effect exists for Merlin — the DROP is carried by Loxley's pace jump and the strumming. If the listener feels the chill without being told, the whole voice program works.
- **The hum is a generated tone** (sub-60 Hz, 2–3 s), not TTS — bible 02.
- **Two-tier render:** XTTS for Fox/Merlin/Aurelius/Loxley; Piper acceptable for Gideon's short declaratives (his creed matches the fast lane). Same bibles.
- **Grade sheet:** Director listens; per-voice A/B on (1) register match, (2) pace law, (3) state distinguishability, (4) never-list intact, (5) the temperature-drop cue. Any voice failing two of five goes back to the bible, not the actor.
