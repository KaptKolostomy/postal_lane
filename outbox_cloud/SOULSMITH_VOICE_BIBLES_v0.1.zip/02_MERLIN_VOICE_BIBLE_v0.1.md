# MERLIN — THE TACTICIAN · VOICE CHARACTERIZATION BIBLE v0.1
[HR-2026-09-19-MARCO-003] · origin: in-house-research · canon sources: personas.md (Merlin), seeds.md (Merlin addendum)

## The voice in one sentence
Grinding iron and static electricity, spoken directly into the mind — a voice that has commanded men who sacked Rome and never needed to be loud, because the dead do not require volume.

## Invariant properties
- **Register:** male, very low (85–100 Hz), sub-bass resonance. The floor of human speech, one step from the grave.
- **Pace:** slow, glacial, with unnatural evenness — no breath sounds where a living man would breathe. He does not breathe; the voice simply continues.
- **Prosody law:** MONOTONE-MASS. No pitch variance except deliberate downward steps at clause ends — each sentence lands like a stone settling in a tomb.
- **Texture (the signature):** layered — base voice + faint metallic grind (iron on iron) + high static hiss at sibilants. Spoken "directly into the mind": narrow stereo image, close-mic presence, no room reverb. He has no environment; he is always closer than he should be.
- **The hum:** his only laugh is a low digital hum from the mask — 2–3 seconds, sub-60 Hz, no pitch contour. It is not laughter; it is acknowledgment.

## Emotional grammar
1. **Report (default):** flat, massive, patient. "The Roman lines broke easily in the old days, Mistress. These modern soldiers are no different." (canon)
2. **Contempt (the only rise he gets):** one-half step UP in grind density, not pitch. "They died in the dark, knowing nothing." (canon)
3. **Devotion (Fox-directed only):** the static softens by 10%. Nothing else changes. This is his entire emotional range for her. "As you command, Mistress. It will be done before the candle burns lower."
4. **The hum (his laugh):** calibration line: [hum] "The old philosopher speaks of peace. He forgets that peace is only built on the bones of those who threatened it." (canon)
5. **Manifest (CALIBRATION-ONLY, DM tier):** the full weight, no mask of courtesy. "I have burned empires, Mistress. Say the word."

## Never-list
- No warmth, no hurry, no fear, no surprise. Fifteen centuries dead does not startle.
- No human breath sounds, no lip noise — he is not breathing through a mouth.
- No volume above conversational. The threat is the content, never the decibels.
- Never addresses anyone but Fox by name. He does not acknowledge the crew; they cannot perceive him.

## Engine notes (the exception case)
No stock engine fits. Chain: XTTS low-male base → sox/ffmpeg: subtle ring-modulation @ 30–40 Hz (iron grind), high-pass hiss layer (static), mono-narrow + close presence (into-the-mind), remove breath artifacts. Tune by ear against the five states. The hum is a generated tone, not TTS.

