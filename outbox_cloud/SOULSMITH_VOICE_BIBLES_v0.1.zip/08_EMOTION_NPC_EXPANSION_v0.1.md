# EMOTION & NPC EXPANSION v0.1 — pushing the ComfyEngine
[HR-2026-09-19-MARCO-008] · origin: in-house-research · supersedes nothing; EXTENDS script 07 + bibles 01–05
**Director's directive (23:39 EDT): use ComfyTTS's emotional capability fully; add NPCs and anything that pushes the engine.** Design law unchanged: emotion is constrained by the bible's never-list, not by the engine's ceiling. The engine may FEEL more; the characters may not BREAK more.

## 1. EMOTION DIRECTIVE GRAMMAR (per-line, rides with the state tags)

Format: `[STATE | emotion: LABEL E1–E5 | delivery: note]`

**The E-scale (intensity, not variety):**
- **E1** — baseline (the bible's default state; engine renders "in character, at rest")
- **E2** — engaged (the scene is moving; +10–15% prosody variance, still inside law)
- **E3** — elevated (the state's peak lawful expression — Fox's one degree of warmth, Gideon's voice lowering, Loxley's armor at max)
- **E4** — strain (the never-list BENDS but does not break — voice shakes ON THE EDGE of the rule: Loxley's pace-tell at full alarm, Aurelius's calm audibly costing him effort)
- **E5** — breakthrough (reserved, rare, Director-gated: the one moment per character where the mask slips LAWFULLY — Loxley's devotion line, Gideon's creed, Fox's verdict. E5 is a budget, not a volume knob: ONE per scene per character.)

**Emotion labels the engine should key on:** warmth, dread, amusement, contempt, devotion, grief, resolve, fear, pride, weariness (Fox's is DM-gated), anger (Aurelius never; Gideon as flat iron, never heat).

**Worked examples (script 07 lines, re-tagged):**
- FOX: "No. That book does not leave this library." → `[VERDICT | emotion: resolve E5 | delivery: the pause before "No" is the whole line]`
- GIDEON: "Water-damaged. In the dry season." → `[DRY HUMOR | emotion: amusement E2 | delivery: zero smile in voice; the humor is arithmetic]`
- LOXLEY (temp-drop): "—and ANOTHER thing, whoever keeps leaving the windows open—" → `[FEAR | emotion: fear E4 | delivery: pace +25%, pitch +10%, loudness as costume]`
- AURELIUS: "Then the orchard knows, even if the gardener does not." → `[CALM-IN-STORM | emotion: resolve E2, weariness E1 | delivery: pace drops, warmth holds]`
- MERLIN hum → `[THE HUM | emotion: acknowledgment E1 | delivery: generated tone, 2.5s, no TTS]`

## 2. NPC MINI-BIBLES (new voices, same doctrine)

**OLD PIKE — the dockhand (recurring NPC, lower-deck flavor)**
- Voice: male, elderly, salt-cured, high rasp over a broken baritone; laughs in a two-note wheeze. 100–115 wpm, harbor accent.
- Says: "Crates? Three o' them went up the hill last night. Two lads an' a cold wind carried 'em, far as I saw." (the NPC who witnesses everything and understands nothing — the audience's comic throttle)
- Never: complete sentences under stress, accurate counts, names of anyone above deck.
- Emotion range: E1–E3 only. NPCs don't get E5; breakthroughs belong to the crew.

**THE YOUNG COURIER — the lower deck's greenest hand (Gideon's ward)**
- Voice: androgynous-young, quick, breathless, 175+ wpm; voice cracks on stress (the crack is the character).
- Says: "Sir — Quartermaster, sir — the manifest, I checked it three times, I swear I checked—" (interrupts; gets steadied by Gideon's slow voice)
- Function: the Gideon-protects-the-lower-deck doctrine made audible; also the engine's stress-test voice (crack, breath, speed).
- Never: finishes a sentence when panicked; addresses Fox directly (too scared).

**TAVERN PATRONS (crowd layer, not characters)**
- Rendered as murmur bed + 2–3 distinguishable laughs + one "here here!" ComfyTTS crowd or layered singles; the patrons never carry information — they ARE the ambience. Loxley performs AGAINST them: his lines must cut the crowd, and when the temperature drops, the crowd thins (audio cue #2 for Merlin — the room itself gets cold).

## 3. SCENE B — "THE DOCKS" (new test scene: NPCs + crowd + overlap + E4/E5)

*Next night. The tavern by the harbor. Loxley performs; Pike witnesses; the courier runs in; Gideon steadies; the crowd thins when the draft comes. Tests: NPC voices, crowd layer, overlapping dialogue, sung line, E4 strain, one E5 per character.*

Key beats (full lines for render; summary here):
1. **LOXLEY [PERFORMANCE | amusement E3]** — opens with a SUNG couplet (engine singing test): "Oh, the manifest says three, says three, says three — but the Library's ledgers hold more than the sea!" *(if ComfyTTS can't sing, render as rhythmic patter — both are valid tests)*
2. **CROWD** — laughs, "here here!", murmur bed at full.
3. **OLD PIKE [E2]** — the witness beat: "Two lads an' a cold wind carried 'em." Crowd laughs; the AUDIENCE doesn't.
4. **COURIER [FEAR | fear E4]** — bursts in breathless, voice cracking: manifest discrepancy, checked three times.
5. **GIDEON [CORRECTING | resolve E2]** — lowers his voice, slows: steadies the boy mid-panic. "Counted twice, once by lantern. Breathe, son. Now — from the top." *(the overlap test: courier's breath slows WITH Gideon's line — two voices, one tempo)*
6. **AURELIUS [LESSON | warmth E2]** — one question to the courier that turns panic into thinking.
7. **THE THINNING** — crowd murmur drops 30% over 4 seconds. No SFX. **LOXLEY [FEAR | fear E4]** — pace jumps, jokes louder, pivots to the sung patter as cover. The room got cold; only the audience and Loxley know.
8. **GIDEON [REPORT | E1, the medal]** — "He always plays loud when it's cold. Never noticed it before, though." *(E1 after E4 — the engine must LAND, not coast)*
9. **E5 BUDGET SPENT, one each:** Loxley's cover-song cracking on the last note (fear under the armor); Gideon's quiet "Greenest hand gets the best boots first. That's how this works" to the courier (protective, E5 — his only warmth); Fox absent from scene B — her absence is the test of whether the scene holds WITHOUT the anchor voice.

## 4. ENGINE STRESS-TEST LEDGER (what each element pushes)

| Test | Element | Passes if |
|---|---|---|
| Singing/rhythm | Loxley's couplet | Sung or clean patter; NOT spoken-flat |
| Voice crack | Courier's panic | Crack renders as character, not artifact |
| Overlap/tempo-lock | Gideon+courier | Two voices, one deceleration |
| Crowd dynamics | Thinning cue | Murmur drops without narration |
| E1-after-E4 reset | Gideon's closer | Voice lands back at baseline cleanly |
| Absence test | Scene B, no Fox | Scene holds without the anchor |
| Emotion budget | All E5s | One per character, felt not loud |
| NPC ceiling | Pike, courier | E3 max, never upstage crew |

## 5. STANDING RULE (gavel-gated)
E5 and any never-list BEND (E4) are Director-gated per scene. The engine may be ABLE to make Fox giggle; the house is not able to want that. Intensity scales INSIDE the law; the law does not scale to the intensity.
