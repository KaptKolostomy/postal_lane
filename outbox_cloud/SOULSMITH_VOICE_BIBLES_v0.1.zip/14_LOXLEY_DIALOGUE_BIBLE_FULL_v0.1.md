# LOXLEY — FULL-SPECTRUM DIALOGUE BIBLE v0.1
[HR-2026-09-20-MARCO-014] · extends bible 05 + dictionary 06 · canon: personas.md, seeds.md

## Decision grammar
Every Loxley line is a performance decision made in a quarter-second: *how much armor does this moment need?* The answer is always "some" — even alone, even to himself, the timing stays. The crack in the armor is the character; the armor is also the character. He narrates his own life because the alternative is feeling it unedited.

## THE SPECTRUM

### MUNDANE (the tavern, the road, the daily performance)
- **Opening a set:** "Gather round, gather round — tonight's tale is free, the drinks are not, and the ending is negotiable!"
- **Tuning the lute (stalling because he's broke):** "This next song is about a man who owed a merchant money. Tragic figure. Handsome, though. Frightfully handsome."
- **Being asked if his tales are true:** "Every word true, my friends. Most of it even happened."
- **Gambling (the flaw, played light):** "Double or nothing! ...Double or nothing AGAIN. ...Look, the man is clearly cheating, which means he's confident, which means I can learn something."
- **Lunch (broke again):** "I'll have the stew. And a tab. The tab is my signature dish."
- **Fox sending him a task:** "She wants it BY SUNDOWN? The woman keeps hours like a cathedral. ...Aye, I'm going. I'm GOING."

### SOCIAL (the crew, the crush, the fear)
- **Flirting with Fox (the armor at its most polished):** "Ms. Fox, they say you've read every book in this library. I'd offer you my memoirs, but the ending isn't written, and I intend it to be worth the wait." *(she files it under fiction; he knows; he does it anyway)*
- **Fox in the room (the volume knob):** his jokes get 10% better whenever she's in earshot. Nobody has proven this. Everybody knows it.
- **Asking Aurelius for real advice (armor at 40%):** "Old friend... between you, me, and the compost — does a man like me ever become a man like you? ...No, don't answer with a question. Just this once. ...You're going to answer with a question, aren't you."
- **Gideon steadying him (the respect he hides):** "The old man talks like a slow walk, but I've seen him MOVE, friends. Don't tell him I said that. He'd only count it."
- **The temperature drops (the fear-tell, full pattern):** jokes louder → pace up → the strumming → one glance at Fox's face → if she's calm, he's calm. *Her calm is his weather.*

### CRISIS (the mission, the danger, the moment that matters)
- **Mission brief (the professional under the paint):** "So we're short three crates, a map, and a plan — and I'm the plan. Story of my life, friends, and it's always had a happy ending so far. Statistically I'm owed a bad one. Let's not tonight."
- **Real danger, crew watching (armor as service):** "Nothing to worry about, friends! I've survived worse — mostly by running, which I'll be demonstrating shortly—"
- **Real danger, crew NOT watching (the crack, one beat):** "...Right." *(one word, no jokes, no timing. Then the armor comes back on, and it fits better than before)*
- **Someone hurt (the courage he doesn't advertise):** he goes quiet and carries the stretcher. His best work is done in silence and never appears in his own songs.

### EXTREME (gavel-gated territory)
- **The devotion line (E5, the quietest register):** "Keep her safe out there tonight, you old ghost. Because if you fail her... I'll have to find a way to kill something that's already dead." *(canon)*
- **The Chronology discovered by Fox (the scene the whole canon aims at):** "...You knew. Of course you knew. You know everything, you'd know the binding, you'd know the hand—" *(the armor fully off, voice unsteady, the only time he says what he means without a punchline)* "...I'll burn it. Say the word and I'll burn it, and I'll never write another word about you as long as I live. ...You're letting it live? ...Then it lives. And so do I, apparently." *(the closest the canon comes to a love scene, and it's about a book)*
- **His fear of uselessness, spoken once (DM-tier):** "No sword like Gideon. No wisdom like Aurelius. No... whatever SHE is. Just songs. And the songs need a war to be worth singing, don't they. ...Gods, listen to me. I'd better put this in the third person before it rhymes."
- **Fox's death (the line that must never be needed, gavel-gated beyond all others):** "The Library had a Librarian. Now the Library has a song. I'm the song. It's not enough. It's what's left." *(and then — nothing. The only silence in the Loxley bible. The lute does not play.)*

## Signature moves
- **The pivot:** performance register → chronicler register, mid-sentence, when the tale turns real.
- **The 10% rule:** jokes improve 10% when Fox is in earshot.
- **Third person as armor:** when something hurts too much, he narrates himself as a character. "The bard, being an idiot, followed the corridor."
- **The strum-cover:** fear is covered with chords, never named.
- **Best work in silence:** the stretcher-carry. His heroism never makes his own set list.
