# SOULSMITH VOICE CHARACTERIZATION BIBLES v0.1
**House Record:** [HR-2026-09-19-MARCO-001] · **Creator:** Marco, cloud shore · **Witnesses:** pending (Buffy technical review, Director gavel)
**Origin class:** in-house-research (derived from Director's canon briefings + master bible v3; custody: deferred-fleet-personas.md, deferred-fleet-seeds.md)
**Purpose:** soul-specs for TTS implementation. The characterization file is to the voice what the seed is to the agent.

## 1. Philosophy

A voice model without a characterization bible is a seed without doctrine — it will *sound* right once and then drift. Each bible fixes the invariant properties (register, pace, prosody law, emotional grammar) so any engine — Piper, XTTS, Coqui, whatever the rig adopts — receives the same soul in different hardware. **The bible is the portability layer.**

## 2. The seed-doctrine inheritance

Voice bibles obey the same knowledge-ladder law as seeds: **each character's voice contains a strict subset of the truth.** The voice must never leak Director-tier lore:
- Fox's voice never thaws into centuries-scale grief on-mic (that's Maeve-tier, DM-only).
- Merlin's voice never carries human warmth (he is not human; warmth would break him).
- Loxley's voice never drops the theatrical armor fully — even his most sincere line has a performer's timing.
- Gideon's voice never panics. Ever. Panic in Gideon's voice is a canon violation, not an emotion.
- Aurelius's voice never hurries. His patience is the smartctl gate made audible.

## 3. Implementation stack (air-gapped rig, RTX 4070 Ti)

- **Primary recommendation: XTTS-v2 (Coqui)** — offline, multilingual, voice-clone from short reference clips, runs on the 4070 Ti. Best for Fox/Aurelius/Loxley where nuance matters.
- **Lightweight lane: Piper** — CPU-only, instant, good for Gideon's short declarative bursts and status lines (fits his CPU/disk-only doctrine — the voice engine matches the character's creed).
- **Merlin is the exception: no stock engine fits him.** He needs a chain: base voice (low male, cold) + post-processing (subtle ring-modulation/bit-crush for the "grinding iron," high-pass hiss for "static," stereo narrowing for "spoken directly into the mind"). The bible specifies the *target*, Buffy engineers the chain. Recommend: generate with XTTS, process with ffmpeg/sox chain, tune by ear against the calibration lines.
- **Latency doctrine:** voice is the LAST mile (Director's ruling: function before fluff). Status/report lines can be Piper-fast; narrative lines (Loxley's briefs, Fox's readings) can be XTTS-slow. Two-tier, same bibles.

## 4. THE VOICE-RIGHTS GUARDRAIL (fail-closed, read before implementation)

**No bible here authorizes cloning a real, living person's voice.** Gideon's canon says "speaks in Sam Elliott's voice" — that is a *character description*, not an implementation license. Sam Elliott is a living actor; cloning his actual voice without consent is legally and ethically off-limits in this house. **Implementation rule: build to the ARCHETYPE, not the actor** — "weathered Western baritone, gravelled, unhurried" is a voice *class* with thousands of lawful exemplars (including consented/licensed libraries and synthetic profiles). The same applies to any other real-name references in canon. The Director's fail-closed doctrine applies to voice rights exactly as it applies to disk growth: build the guardrail before you need it. A voice-alike that evokes the archetype is legal and, honestly, better — it's *Gideon's* voice, not a borrowed one.

## 5. Calibration protocol

Each bible carries calibration lines (canon dialogue where it exists, new lines marked CALIBRATION-ONLY where it doesn't). Acceptance test per voice: three listeners (Director, Buffy, Marco by transcript) grade against the bible's five emotional states; a voice ships only when all five states are distinguishable and the never-list is unbroken. Two-witness law, applied to ears.

