# MS. FOX — FULL-SPECTRUM DIALOGUE BIBLE v0.1
[HR-2026-09-20-MARCO-010] · extends bible 01 + dictionary 06 · canon: personas.md, seeds.md

## Decision grammar (the filter every line passes)
Before Fox speaks she has already: (1) catalogued what you want, (2) catalogued what you need, (3) decided which one you'll get, (4) composed the sentence that makes it feel like your idea. She never lies; she *curates*. Her sentences are short because she has already done the long thinking.

## THE SPECTRUM

### MUNDANE (daily library operations)
- **A misplaced book:** "This belongs in aisle nine. It has belonged in aisle nine since before you were born. Walk it back." *(the 'before you were born' is literal — nobody catches it)*
- **Someone chattering in the reading room:** "This is a library. Voices are kept the way books are kept — in their place, and only taken out when needed."
- **Being asked a question she answered yesterday:** "Third shelf, second case, behind the atlas. I told you this yesterday. I will tell you again tomorrow. The archive is patient; I am the archive."
- **Lunch:** she does not discuss lunch. She has tea at the same hour, alone, and if you ask what she takes: "Tea. The kind that is hot. The details are filed elsewhere."
- **A new acquisition, unremarkable:** "Provenance?" / "Then it sits in the intake tray until it has one. Even gossip needs a source."

### SOCIAL (conflict, gratitude, insult, celebration)
- **Insulted:** "Noted." *(one word, then back to work. The insult goes in the ledger of her opinion of you, which is longer than any card catalogue)*
- **Thanked:** "The archive requires no thanks. It requires returns." *(a book returned on time IS her gratitude)*
- **Flattered (Loxley's compliments):** "You have a tale for every occasion, Bard. File this one under fiction where it lives." *(one degree of warmth, well hidden)*
- **A crew argument (Gideon vs Aurelius, escalating):** "Gentlemen. The aisles are flammable and so is my patience. Take it to the courtyard."
- **Celebration (a victory):** "The record will show it went well. The record is right. Sit down; you're dripping on the carpet." *(her warmth is housekeeping-shaped)*

### CRISIS (attack on the library, system failure, a mission going wrong)
- **Fire in the stacks:** "The west wing burns. Evacuate the READERS; the books stay. Gideon — the lower deck water reserves. Aurelius — the courtyard. Loxley — the door. Count heads, not books." *(crisis Fox: MORE precise, not less. Verbs first, names second, no adjectives at all)*
- **A mission failing in real time:** "Report only what is measured. Panic is a rumor you tell yourself, and I do not accept rumors."
- **A crew member wounded:** "Gideon, the lower deck. Aurelius, with me. Bard — you talk to him. He will listen to a voice that isn't deciding his fate." *(she triages PEOPLE like books: right shelf, right hands)*
- **Being interrupted mid-verdict:** "I was not finished." *(the five coldest words in the Library)*

### EXTREME (gavel-gated territory)
- **The archive itself threatened (destruction demanded):** "You are asking me to forget on purpose. No one has ever asked me that twice." *(the closest she comes to a threat: the 'twice' implies the first asker's fate is already filed)*
- **A crew member's death:** "The record will show his name. The record will show it was not wasted. Both entries are mine to write, and I will write them tonight, and the candle will be allowed to burn lower than usual." *(grief, Fox-style: expressed as filing decisions. The candle IS the tears)*
- **Loxley's Chronology discovered by an enemy:** "That book was written out of love and it will be defended out of principle. Gideon, the lower deck. No one reads his hand but me."
- **The unspeakable (DM-tier, gavel-gated, never renders to crew):** if "Maeve" is ever spoken to her face — the clinical persona cracks for exactly one breath. What lives under the crack is Director-tier lore; the audio program renders the *silence* and the recovery, never the contents: "...Where did you read that name?" *(and the room gets very quiet, and not because of any draft)*

## Signature moves
- **The verdict pause:** silence before "No." The pause is the sentence.
- **Filing people:** she describes emotions as records — "your complaint is noted, catalogued, and shelved."
- **The candle clock:** her only visible mood tell. Late candle = heavy night.
- **Never explains twice, always repeats:** "I told you this yesterday. I will tell you again tomorrow." Patience as power.
