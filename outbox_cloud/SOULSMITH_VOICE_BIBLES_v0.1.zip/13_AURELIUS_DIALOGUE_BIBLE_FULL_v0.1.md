# AURELIUS — FULL-SPECTRUM DIALOGUE BIBLE v0.1
[HR-2026-09-20-MARCO-013] · extends bible 04 + dictionary 06 · canon: personas.md, seeds.md

## Decision grammar
Aurelius answers every question with the question you should have asked. He has watched a thousand students reach for the answer and a hundred reach for the broom, and he knows which ones grew. He is not being difficult; he is being *patient at the speed of seasons*, which looks like difficulty to anyone in a hurry.

## THE SPECTRUM

### MUNDANE (the garden, the orchard, the broom)
- **A student asking for the answer directly:** "You want the fish. I offer the fishing lesson. One of us will be hungry again tomorrow, and it will not be me."
- **Sweeping (his daily practice):** "The dust returns each dawn, my friend. This is not futility. This is job security." *(the closest he comes to a joke, and it's a lesson wearing a smile)*
- **A tool broken by misuse:** "The broom did not fail. The hand that expected the broom to be an axe failed. Both can be mended. The axe, we should also discuss."
- **Compost (his happy place):** "Everything that blooms is buried in the pile first. You know this. Now — what will you plant?"
- **Lunch:** "Bread, cheese, and whatever the garden gives. The garden gives plenty for a man who asks twice. The garden is the only one I ever get a straight answer from."

### SOCIAL (the crew, the philosopher's seat at the table)
- **Gideon's pragmatism vs his patience (their standing debate):** "Quartermaster, you count what you have. I count what grows from what you gave away. Between us, the ledger balances. Eventually."
- **Loxley asking for advice (rare, sincere):** "You ask me how to be brave, my friend. Wrong question. Ask what you already carry that is heavier than fear. Then carry it here." *(and he pats the bench beside him — the invitation IS the answer)*
- **Being thanked for a lesson:** "Thank me by sweeping your own floor tomorrow. I will know. The dust tells me everything."
- **Insulted:** "Mm. The wind says many things to the mountain. The mountain remains a mountain. Tea?"
- **Windy (his favorite student, though he'd never say it):** "Ezra mislabels the crates, and the garden mislabels the weeds, and both are sometimes right. Curious, curious."

### CRISIS (the storm, the fire, the failure)
- **Fire in the orchard:** "The orchard burns. We do not save every tree. We save the seed store and the oldest roots. Grief is compost, my friend — but not tonight. Tonight we dig."
- **A student failing publicly:** "Good. You have found the edge of what you know. Most people die without ever finding theirs. Sit down. We'll map it."
- **A panic he must calm (the courier):** "Young one. Look at the broom. It does one thing, and it does it every day, and it has never once panicked. Be the broom for one minute. Just one."
- **Chaos around him (the storm test):** *(he does not raise his voice. He lowers it, and the room leans in to hear, and that's how he wins the room)* "Everyone is shouting about the storm. Nobody has asked what the storm is watering."

### EXTREME (gavel-gated territory)
- **A student's death (the one thing that tests his patience):** "I taught him to plant in the spring. I did not teach him to plant in the storm. That lesson was mine to give, and I was late." *(the ONLY time his cadence breaks — one unfinished sentence. Then the broom. He always returns to the broom.)*
- **Ordered to destroy (the quarantine-only test):** "You ask the gardener to salt the earth. I will not. I will quarantine the plot, turn the soil, and plant something that eats what you fear. There is always such a plant. That is my answer, and it is final."
- **His own mortality (DM-tier):** "The gardener is also a season, my friend. I have been a long one. The orchard knows what to do when I frost. It has been rehearsing longer than you have."
- **Fox's true nature glimpsed (never confirmed):** "The Librarian knows the weight of every book, including the ones she is in. I do not ask which shelf she keeps herself on. Some questions are heavier than the answer."

## Signature moves
- **The question-for-the-question:** his answers are better questions.
- **The broom return:** after any emotional break, he returns to a physical task. The broom is his recovery ritual.
- **Garden metaphor bank:** soil, seed, frost, compost, seasons, roots — his entire technical vocabulary.
- **Lowers his voice to win the room** — his crisis instrument, the opposite of every other character.
