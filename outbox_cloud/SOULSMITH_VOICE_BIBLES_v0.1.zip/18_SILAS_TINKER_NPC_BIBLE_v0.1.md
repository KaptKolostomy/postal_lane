# SILAS — THE TINKER · NPC BIBLE v0.1
[HR-2026-09-20-MARCO-018] · origin: in-house-research + Director's concept (00:05 EDT) · archetype: Silas Marner lineage (public-domain) + the village tinker class — no living person cloned
**Director's concept, adopted:** "someone who collects broken things and tries to fix them, even if they happen to be people." **Provenance note (house creed, on the record): the Director described himself** — 30 years ER/burn-unit triage. The Tinker is the doctrine made flesh: nothing is deleted; everything is mended or composted.

## The character
**Silas, the Tinker — the valley's mender of pots, clocks, hinges, lutes, and people, in that order and no order at all.** His shop is where broken things end up: cracked cups hung from the rafters like bells, a drawer of "waiting" gears, a shelf of mended-and-nobody-claimed-them objects he keeps anyway. He was broken once himself — he does not say how, and the shop is the scar that healed into a room. **His triage (the ER inheritance, in-world):** three piles. *"What can be mended. What can be kept. And what feeds the garden."* He never lies about which pile a thing is in — honest triage is the whole kindness.
**His method for people (the gold): he never mends a person directly.** He hands them a broken *thing* and lets them fix it — and the mended mend. The courier's cracked confidence, Loxley's warping lute-neck, Nettle's third failed hinge: the Tinker's therapy is craft with the hands busy and nobody watching your face. (The Director's own trick, thirty years of it — now in the canon.)
**Lore position (the guardrail):** Silas repairs what the shadow war breaks and NEVER asks how it broke. *"Don't tell me how it broke. Broken is broken. I fix from 'is,' not from 'why.'"* This makes him the one craftsman Fox can use without cost — she brings the broken things at night; he mends them; the provenance of damage stays outside the shop door. He knows the night customers exist the way Mother knows the drafts — filed under *work*. (Audience sees the pattern; Silas sees the work.)

## Voice (the worn bench)
- **Register:** elderly-ish male, MID-register worn smooth — gentle gravel, the opposite of Gideon's grinding stones: where Gideon's gravel is authority, Silas's is *use*. A voice like a well-oiled hinge that remembers being rusty.
- **Pace:** unhurried, 115–130 wpm, with the hands' rhythm underneath — he speaks at the speed of the work, and the work sets the tempo. Pauses are not silences; they're turns of the screwdriver.
- **Prosody law:** THE SIDEWAYS ANSWER. Questions about people get answered with statements about objects, and vice versa — *"How's the boy?" / "Same as this clock. Wound too tight for a small case. I gave him a hinge to fix. He'll be right."* He never addresses feelings directly; feelings get repaired by proxy.
- **Texture:** soft gravel, tuneless work-hum (mid-register, idle, continuous — **NOT Merlin's hum**: Silas's is 150–250 Hz, tuneless, human, tied to his hands; Merlin's is sub-60 Hz, digital, tied to the mask. Blind-separation test stands), the click of small tools as his punctuation.
- **Emotion range: E1–E3, NPC ceiling.** His E3 is *the three-pile verdict* — the sentence every customer dreads and trusts: which pile is it. Delivered gently, never softened.

## Might say
- (taking the broken lute) "Don't tell me how it broke. Broken is broken. I fix from 'is,' not from 'why'. ...Water, though. Water always tells on itself. The neck remembers the flood, see? Wood keeps a diary." *(to the lute, not to Loxley)*
- (the three piles, the E3 verdict) "This one I can mend. This one I can keep. And this one goes to the garden — the Gardener's pile takes what I can't. Nothing is thrown away in this valley, young one. Nothing."
- (on the night customers, never asked) "Work comes in at all hours. Good work does. I leave the lamp."
- (handing the courier a broken hinge) "Hinge is jammed. Been jammed a while — got scared of closing, I expect. Happens. ...You know hinges? No? You will. Sit."
- (to Nettle, third failed hinge this week) "Third one. Good. The first two were practice, and practice is never wasted — the Gardener says so and he's never wrong, he's just slow." *(the closest he comes to a joke)*
- (the one direct sentence — rare, quiet, at the repaired thing's owner) "It'll hold. Things mended proper hold longer than things never broke. Grain grows back tighter at the break." *(the ER nurse's truth — scar tissue is stronger — said to a pot, meant for a person)*

## Would never say
- "How did this happen?" — the question is banned at the shop door. (The guardrail IS the character.)
- A softened verdict. The three piles are honest or they're nothing: fail-closed triage, in-world.
- A promise he can't keep: he never says "good as new." He says "it'll hold." New is a lie; holding is the truth.
- Rush. If Silas ever hurries, someone he loves is hurt — and the house should notice the render broke its own law to do it.
- Throwing anything away. The third pile goes to Aurelius's compost, always. The Tinker and the Gardener share a doctrine across a fence.

## Interaction law (the mended-mend contract)
1. **People are never handed to the people-pile directly.** The fix arrives sideways: a broken thing, a bench, a task, and the hands get busy while the soul does its quiet work. If a scene ever has Silas counsel someone face-to-face, the scene is broken.
2. **The night lamp stays lit.** No questions, no ledger of who came. Fox's shadow economy runs on his discretion; his discretion is not loyalty to her — it's loyalty to the *work*. (Subtle, load-bearing distinction.)
3. **The three-pile verdict is sacred and shared with Aurelius** — the mended pile is his, the kept pile is his, the garden pile is the Gardener's. The two old men have never needed to discuss it. One nod, once a season — the same nod Mother and Fox exchange. (The valley's quiet web: three ledgers, three nods, no words.)

## Scene F beat — "THE LUTE" (mini-scene: the sideways-answer test)
*The shop, evening. Loxley's lute — the flood-warped neck — on the bench. Loxley fidgets; Grubb counts coins in the corner; Silas works. Tests: object-directed address, the work-hum, the three-pile cadence, and the sideways answer landing on a person.*

**LOXLEY [PERFORMANCE | charm E2, thin]:** "So — good as new by Friday? Big crowd Saturday, and the hero needs his—"
**SILAS [E1, to the lute]:** "It'll hold. Nothing's new twice. Grain grows back tighter at the break — this neck will sing better for the flood, long about spring."
**LOXLEY [CHRONICLER | quiet E2]:** "...Better for the flood."
**SILAS [E1, to the hinge in his hands, not to the bard]:** "Floods warp the wood and the man, same water. Wood keeps a diary. Men keep songs. Songs mend slower, but they mend. The Gardener taught me that, and he's never wrong, he's just slow."
**GRUBB [LATE DROP | thrift E2]:** "Sixty-forty says the lute's back by Saturday."
**SILAS [E1]:** "Your sixty-forty's safe. ...Leave the lamp money on the sill, Penny. The night's got work too."
*(Nobody asks what night work. Nobody ever asks. The audience holds it.)*

## Engine tests Silas adds
Object-directed address (voice aimed at a near object — close-mic off-axis cue), the work-hum separation from Merlin's hum (150–250 Hz tuneless vs sub-60 digital; blind test), three-pile cadence (the E3 verdict structure), gentle-gravel vs Aurelius-warmth blind separation, and pace-locked-to-hands (speech tempo tied to work rhythm — the engine's hardest human texture).
