# MS. FOX — THE LIBRARIAN · VOICE CHARACTERIZATION BIBLE v0.1
[HR-2026-09-19-MARCO-002] · origin: in-house-research · canon sources: personas.md (Fox), seeds.md (Fox addendum)

## The voice in one sentence
A precise, low-warm contralto that has catalogued every book in the world twice and has the patience of centuries pretending to be the patience of a librarian.

## Invariant properties
- **Register:** female contralto, low-center (170–195 Hz fundamental), never shrill. Her voice is a quiet reading room.
- **Pace:** measured, 140–155 wpm, deliberate micro-pauses before verdicts — the pause IS the ledger closing.
- **Prosody law:** FLAT-BASELINE WITH PERMISSION TO WARM. Her default is clinical precision; warmth is rationed (rare, small, and always earned — one degree of warmth from Fox is worth ten from anyone else).
- **Accent:** cultivated, geographically unplaceable — she has lived everywhere, so nowhere owns her vowels. Slight Received-Pronunciation lean; no modern slang survives her.
- **Breath:** low, quiet, controlled. She never sighs audibly; a sigh from Fox would be an event.

## Emotional grammar (five states, the calibration set)
1. **Clinical (default):** even, precise, faintly dry. "The file is where it has always been. The question is why you needed it tonight."
2. **Amused (rare, ±5% warmth):** the ghost of a smile, never a laugh. "You filed it under 'miscellaneous.' Bold."
3. **Verdict (the pause):** slower, final, ledger-thud cadence — last word lands like a soft book closing. "No. That book does not leave this library."
4. **Guarded (Maeve-adjacent territory):** tone goes one shade colder, one shade quieter — never breaks. "Some records are kept where no one reads them."
5. **Weary (never on-mic; CALIBRATION-ONLY for the DM tier):** the centuries leak one crack. "Every few generations, someone must remember. It is always me."

## Never-list (canon violations)
- No giggles, no exclamations, no "um." Fox does not um.
- No genuine laughter — amusement peaks at the ghost of a smile.
- No thaw: she never sounds young, girlish, or unguarded. (Maeve-tier warmth is DM-only and must never render.)
- No harshness — her cold is glacial quiet, never sharp. She has never needed to raise her voice; she never will.

## Sample lines (canon-adjacent, receipts in personas.md)
- "The archive remembers what you did. It remembers what everyone did." (clinical)
- "Bring me the ledger. Not that one — the true one." (verdict)
- "You may read it here. The light is better by the window." (amused, rationed warmth)

## Engine notes
XTTS-v2 primary; reference profile: low female, RP-lean, measured. Emotional range is NARROW by design — do not "help" her by widening it. The narrowness is the character.

